<?php

//*********************************************************
// This php local govt. database form post component
// written by DJ @kraziegent
//
// version 1.00 (11 October 2013)
//*********************************************************

    $state = $_POST['state']; 
    $local_govt = $_POST['LocalGovt']; 
  
  echo "You selected $local_govt local government in $state State Nigeria. Setup was Successful";

?>