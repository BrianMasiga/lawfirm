<?php
//*********************************************************
// This php local govt. database constants component
// written by DJ @kraziegent
//
// version 1.00 (11 October 2013)
//*********************************************************

//Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "states_local_govt");

?>